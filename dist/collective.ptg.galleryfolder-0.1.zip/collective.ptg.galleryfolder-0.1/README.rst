Introduction
============

adds a gallery content type (basically just a folder with a new name) to be used with collective.plonetruegallery