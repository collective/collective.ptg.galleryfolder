"""Common configuration constants
"""

PROJECTNAME = 'collective.ptg.galleryfolder'

ADD_PERMISSIONS = {
    # -*- extra stuff goes here -*-
    'Galleryfolder': 'collective.ptg.galleryfolder: Add Galleryfolder',
}
