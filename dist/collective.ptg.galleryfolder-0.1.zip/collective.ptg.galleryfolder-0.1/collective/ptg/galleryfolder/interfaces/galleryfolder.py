from zope.interface import Interface
# -*- Additional Imports Here -*-


class IGalleryfolder(Interface):
    """Gallery Content Type for Plone Truegallery"""

    # -*- schema definition goes here -*-
